package com.example.darkstorm;

import net.minecraft.client.Minecraft;
import net.minecraft.world.World;
import net.minecraftforge.client.event.EntityViewRenderEvent;
import net.minecraftforge.event.terraingen.BiomeEvent;
import net.minecraftforge.fml.common.eventhandler.SubscribeEvent;
import net.minecraftforge.fml.common.gameevent.TickEvent;

public class WeatherHandler {
    private int lastKey = -1;

    // ---- Cimen ve yaprak ----
    @SubscribeEvent
    public void onGrass(BiomeEvent.GetGrassColor e) {
        float[] c = WeatherColors.pick(WeatherColors.GRASS, WeatherColors.q(WeatherColors.rain()), WeatherColors.q(WeatherColors.thunder()));
        e.setNewColor(WeatherColors.blendInt(e.getOriginalColor(), c, 0.7F));
    }

    @SubscribeEvent
    public void onFoliage(BiomeEvent.GetFoliageColor e) {
        float[] c = WeatherColors.pick(WeatherColors.GRASS, WeatherColors.q(WeatherColors.rain()), WeatherColors.q(WeatherColors.thunder()));
        e.setNewColor(WeatherColors.blendInt(e.getOriginalColor(), c, 0.7F));
    }

    // Hava degisince chunk'lari yenile ki cimen rengi guncellensin
    @SubscribeEvent
    public void onTick(TickEvent.ClientTickEvent e) {
        if (e.phase != TickEvent.Phase.END) return;
        Minecraft mc = Minecraft.getMinecraft();
        if (mc.world == null || mc.player == null) { lastKey = -1; return; }
        int key = Math.round(WeatherColors.rain() * 4F) * 8 + Math.round(WeatherColors.thunder() * 4F);
        if (lastKey == -1) { lastKey = key; mc.renderGlobal.loadRenderers(); return; }
        if (key != lastKey) { lastKey = key; mc.renderGlobal.loadRenderers(); }
    }

    // ---- Gokyuzu / sis ve yildirim flasi ----
    @SubscribeEvent
    public void onFog(EntityViewRenderEvent.FogColors e) {
        World w = Minecraft.getMinecraft().world;
        if (w == null || w.provider.getDimension() != 0) return;
        if (e.getState().getMaterial().isLiquid()) return;

        float[] sky = WeatherColors.pick(WeatherColors.SKY, WeatherColors.rain(), WeatherColors.thunder());
        float day = w.getSunBrightness(1.0F);
        day *= day; // gece koyu kalsin

        float r = sky[0] * day, g = sky[1] * day, b = sky[2] * day;

        float f = (w.getLastLightningBolt() - (float) e.getRenderPartialTicks()) / 2.0F;
        if (f > 0) {
            if (f > 1) f = 1;
            r = WeatherColors.mix(r, WeatherColors.FLASH[0], f);
            g = WeatherColors.mix(g, WeatherColors.FLASH[1], f);
            b = WeatherColors.mix(b, WeatherColors.FLASH[2], f);
        }
        e.setRed(r);
        e.setGreen(g);
        e.setBlue(b);
    }
}
