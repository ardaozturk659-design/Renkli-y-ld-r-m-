package com.example.darkstorm;

import java.util.Random;

import net.minecraft.client.renderer.BufferBuilder;
import net.minecraft.client.renderer.GlStateManager;
import net.minecraft.client.renderer.Tessellator;
import net.minecraft.client.renderer.entity.Render;
import net.minecraft.client.renderer.entity.RenderManager;
import net.minecraft.client.renderer.vertex.DefaultVertexFormats;
import net.minecraft.entity.effect.EntityLightningBolt;
import net.minecraft.util.ResourceLocation;
import net.minecraft.util.math.MathHelper;

public class RenderColorLightning extends Render<EntityLightningBolt> {

    // Acik (pastel) yildirim renkleri
    private static final float[][] PALETTE = {
        {1.00F, 0.60F, 0.75F}, // pembe
        {0.60F, 0.85F, 1.00F}, // acik mavi
        {0.65F, 1.00F, 0.70F}, // acik yesil
        {1.00F, 0.95F, 0.55F}, // acik sari
        {0.80F, 0.65F, 1.00F}, // acik mor
        {1.00F, 0.75F, 0.50F}  // acik turuncu
    };

    private static float mix(float a, float b, float t) { return a + (b - a) * t; }

    // Renk, bolt'un konumundan secilir: konum her client'ta ayni oldugu icin
    // moddaki tum oyuncular ayni renkli yildirimi gorur.
    private static float[][] layersFor(EntityLightningBolt e) {
        int h = MathHelper.floor(e.posX) * 73856093 ^ MathHelper.floor(e.posZ) * 19349663;
        float[] c = PALETTE[Math.floorMod(h, PALETTE.length)];
        float[][] L = new float[4][4];
        float[] white = {mix(c[0], 1, 0.7F), mix(c[1], 1, 0.7F), mix(c[2], 1, 0.7F)};
        float[] mid = {mix(c[0], 1, 0.3F), mix(c[1], 1, 0.3F), mix(c[2], 1, 0.3F)};
        L[0] = new float[]{white[0], white[1], white[2], 0.90F};
        L[1] = new float[]{mid[0], mid[1], mid[2], 0.45F};
        L[2] = new float[]{c[0], c[1], c[2], 0.35F};
        L[3] = new float[]{c[0], c[1], c[2], 0.25F};
        return L;
    }

    public RenderColorLightning(RenderManager manager) {
        super(manager);
    }

    @Override
    public void doRender(EntityLightningBolt entity, double x, double y, double z, float entityYaw, float partialTicks) {
        Tessellator tessellator = Tessellator.getInstance();
        BufferBuilder buf = tessellator.getBuffer();

        GlStateManager.disableTexture2D();
        GlStateManager.disableLighting();
        GlStateManager.enableBlend();
        // Additive blend: acik renkler parlar
        GlStateManager.blendFunc(GlStateManager.SourceFactor.SRC_ALPHA, GlStateManager.DestFactor.ONE);
        GlStateManager.depthMask(false);

        float[][] layers = layersFor(entity);
        double[] ox = new double[8];
        double[] oz = new double[8];
        double d0 = 0.0D, d1 = 0.0D;
        Random random = new Random(entity.boltVertex);

        for (int i = 7; i >= 0; --i) {
            ox[i] = d0;
            oz[i] = d1;
            d0 += random.nextInt(11) - 5;
            d1 += random.nextInt(11) - 5;
        }

        // Dis katmandan ice dogru ciz ki cekirdek ustte kalsin
        for (int layer = 3; layer >= 0; --layer) {
            float[] c = layers[layer];
            Random random1 = new Random(entity.boltVertex);

            for (int j = 0; j < 3; ++j) {
                int k = 7;
                int l = 0;
                if (j > 0) k = 7 - j;
                if (j > 0) l = k - 2;

                double d2 = ox[k] - d0;
                double d3 = oz[k] - d1;

                for (int i1 = k; i1 >= l; --i1) {
                    double d4 = d2;
                    double d5 = d3;

                    if (j == 0) {
                        d2 += random1.nextInt(11) - 5;
                        d3 += random1.nextInt(11) - 5;
                    } else {
                        d2 += random1.nextInt(31) - 15;
                        d3 += random1.nextInt(31) - 15;
                    }

                    double d6 = 0.1D + layer * 0.2D;
                    if (j == 0) d6 *= i1 * 0.1D + 1.0D;
                    double d7 = 0.1D + layer * 0.2D;
                    if (j == 0) d7 *= (i1 - 1) * 0.1D + 1.0D;

                    buf.begin(5, DefaultVertexFormats.POSITION_COLOR);
                    for (int j1 = 0; j1 < 5; ++j1) {
                        double d8 = x + 0.5D - d6;
                        double d9 = z + 0.5D - d6;
                        if (j1 == 1 || j1 == 2) d8 += d6 * 2.0D;
                        if (j1 == 2 || j1 == 3) d9 += d6 * 2.0D;

                        double d10 = x + 0.5D - d7;
                        double d11 = z + 0.5D - d7;
                        if (j1 == 1 || j1 == 2) d10 += d7 * 2.0D;
                        if (j1 == 2 || j1 == 3) d11 += d7 * 2.0D;

                        buf.pos(d10 + d2, y + i1 * 16, d11 + d3).color(c[0], c[1], c[2], c[3]).endVertex();
                        buf.pos(d8 + d4, y + (i1 + 1) * 16, d9 + d5).color(c[0], c[1], c[2], c[3]).endVertex();
                    }
                    tessellator.draw();
                }
            }
        }

        GlStateManager.depthMask(true);
        GlStateManager.disableBlend();
        GlStateManager.enableLighting();
        GlStateManager.enableTexture2D();
    }

    @Override
    protected ResourceLocation getEntityTexture(EntityLightningBolt entity) {
        return null;
    }
}
