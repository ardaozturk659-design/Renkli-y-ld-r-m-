package com.example.darkstorm;

import net.minecraftforge.common.config.Config;

@Config(modid = DarkStormMod.MODID, name = "colorstorm")
public class ModConfig {
    @Config.Comment("Yildirim rengi (hex, ornek FF0000) ya da random")
    public static String lightning = "random";

    public static String grassClear = "9EF273";
    public static String grassRain = "8CEBCC";
    public static String grassThunder = "F2BFF2";

    public static String skyClear = "B8E6FF";
    public static String skyRain = "CCE0F2";
    public static String skyThunder = "E0C7FF";

    public static void reset() {
        lightning = "random";
        grassClear = "9EF273"; grassRain = "8CEBCC"; grassThunder = "F2BFF2";
        skyClear = "B8E6FF"; skyRain = "CCE0F2"; skyThunder = "E0C7FF";
    }
}
