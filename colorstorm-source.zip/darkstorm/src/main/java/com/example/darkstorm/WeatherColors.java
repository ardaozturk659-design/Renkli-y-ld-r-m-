package com.example.darkstorm;

import net.minecraft.client.Minecraft;
import net.minecraft.world.World;

public class WeatherColors {
    // {acik hava, yagmur, firtina}
    static final float[][] DEF_SKY   = {{0.72F, 0.90F, 1.00F}, {0.80F, 0.88F, 0.95F}, {0.88F, 0.78F, 1.00F}};
    static final float[][] DEF_GRASS = {{0.62F, 0.95F, 0.45F}, {0.55F, 0.92F, 0.80F}, {0.95F, 0.75F, 0.95F}};

    static float[][] SKY = DEF_SKY.clone();
    static float[][] GRASS = DEF_GRASS.clone();
    static float[] LIGHTNING = null; // null = konuma gore rastgele pastel
    static final float[] FLASH = {1.0F, 0.85F, 0.95F};

    /** Config'teki hex yazilarini renge cevirir. */
    static void reload() {
        SKY = new float[][]{hex(ModConfig.skyClear, DEF_SKY[0]), hex(ModConfig.skyRain, DEF_SKY[1]), hex(ModConfig.skyThunder, DEF_SKY[2])};
        GRASS = new float[][]{hex(ModConfig.grassClear, DEF_GRASS[0]), hex(ModConfig.grassRain, DEF_GRASS[1]), hex(ModConfig.grassThunder, DEF_GRASS[2])};
        LIGHTNING = hex(ModConfig.lightning, null);
    }

    static float[] hex(String s, float[] def) {
        try {
            if (s == null) return def;
            s = s.trim();
            if (s.startsWith("#")) s = s.substring(1);
            if (s.length() != 6) return def;
            int v = Integer.parseInt(s, 16);
            return new float[]{((v >> 16) & 255) / 255F, ((v >> 8) & 255) / 255F, (v & 255) / 255F};
        } catch (Exception e) {
            return def;
        }
    }

    static float rain()    { World w = Minecraft.getMinecraft().world; return w == null ? 0 : w.getRainStrength(1.0F); }
    static float thunder() { World w = Minecraft.getMinecraft().world; return w == null ? 0 : w.getThunderStrength(1.0F); }

    static float mix(float a, float b, float t) { return a + (b - a) * t; }

    static float[] pick(float[][] t, float rain, float thunder) {
        float[] out = new float[3];
        for (int i = 0; i < 3; i++) {
            float v = mix(t[0][i], t[1][i], rain);
            out[i] = mix(v, t[2][i], thunder);
        }
        return out;
    }

    static int toInt(float[] c) {
        return ((int) (c[0] * 255) << 16) | ((int) (c[1] * 255) << 8) | (int) (c[2] * 255);
    }

    static int blendInt(int orig, float[] target, float amount) {
        float r = mix(((orig >> 16) & 255) / 255F, target[0], amount);
        float g = mix(((orig >> 8) & 255) / 255F, target[1], amount);
        float b = mix((orig & 255) / 255F, target[2], amount);
        return toInt(new float[]{r, g, b});
    }

    static float q(float v) { return Math.round(v * 4F) / 4F; }
}
