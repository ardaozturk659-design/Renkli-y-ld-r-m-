package com.example.darkstorm;

import net.minecraft.client.Minecraft;
import net.minecraft.command.CommandBase;
import net.minecraft.command.ICommandSender;
import net.minecraft.server.MinecraftServer;
import net.minecraft.util.text.TextComponentString;
import net.minecraftforge.common.config.Config;
import net.minecraftforge.common.config.ConfigManager;

public class ColorCommand extends CommandBase {
    @Override public String getName() { return "renk"; }

    @Override public String getUsage(ICommandSender s) {
        return "/renk yildirim <hex|random> | /renk cimen <acik|yagmur|firtina> <hex> | /renk gokyuzu <acik|yagmur|firtina> <hex> | /renk sifirla";
    }

    @Override public int getRequiredPermissionLevel() { return 0; }
    @Override public boolean checkPermission(MinecraftServer server, ICommandSender sender) { return true; }

    private static void msg(ICommandSender s, String t) { s.sendMessage(new TextComponentString(t)); }

    @Override
    public void execute(MinecraftServer server, ICommandSender sender, String[] a) {
        if (a.length == 0) { msg(sender, getUsage(sender)); return; }

        if (a[0].equals("sifirla")) {
            ModConfig.reset();
        } else if (a[0].equals("yildirim") && a.length >= 2) {
            if (!a[1].equals("random") && !valid(a[1])) { msg(sender, "Gecersiz renk. Ornek: FF0000"); return; }
            ModConfig.lightning = a[1];
        } else if ((a[0].equals("cimen") || a[0].equals("gokyuzu")) && a.length >= 3) {
            if (!valid(a[2])) { msg(sender, "Gecersiz renk. Ornek: FF0000"); return; }
            boolean grass = a[0].equals("cimen");
            switch (a[1]) {
                case "acik":    if (grass) ModConfig.grassClear = a[2];   else ModConfig.skyClear = a[2];   break;
                case "yagmur":  if (grass) ModConfig.grassRain = a[2];    else ModConfig.skyRain = a[2];    break;
                case "firtina": if (grass) ModConfig.grassThunder = a[2]; else ModConfig.skyThunder = a[2]; break;
                default: msg(sender, "Hava: acik, yagmur veya firtina"); return;
            }
        } else {
            msg(sender, getUsage(sender));
            return;
        }

        ConfigManager.sync(DarkStormMod.MODID, Config.Type.INSTANCE);
        WeatherColors.reload();
        Minecraft.getMinecraft().renderGlobal.loadRenderers();
        msg(sender, "Renk guncellendi.");
    }

    private static boolean valid(String s) { return s.matches("#?[0-9a-fA-F]{6}"); }
}
