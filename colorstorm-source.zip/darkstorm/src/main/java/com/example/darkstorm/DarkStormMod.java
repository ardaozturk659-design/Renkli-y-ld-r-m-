package com.example.darkstorm;

import net.minecraftforge.fml.common.Mod;
import net.minecraftforge.fml.common.event.FMLPreInitializationEvent;

@Mod(modid = DarkStormMod.MODID, name = "Color Storm", version = "1.0", clientSideOnly = true)
public class DarkStormMod {
    public static final String MODID = "darkstorm";

    @Mod.EventHandler
    public void preInit(FMLPreInitializationEvent event) {
        ClientSetup.init();
    }
}
