package com.example.darkstorm;

import net.minecraft.entity.effect.EntityLightningBolt;
import net.minecraftforge.client.ClientCommandHandler;
import net.minecraftforge.common.MinecraftForge;
import net.minecraftforge.fml.client.registry.RenderingRegistry;

public class ClientSetup {
    public static void init() {
        WeatherColors.reload();
        RenderingRegistry.registerEntityRenderingHandler(EntityLightningBolt.class, RenderColorLightning::new);
        MinecraftForge.EVENT_BUS.register(new WeatherHandler());
        ClientCommandHandler.instance.registerCommand(new ColorCommand());
    }
}
